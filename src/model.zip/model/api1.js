// api.js
 
import Vue from 'vue';
import Modal from './eldialog'
export default function(message) {
    console.log('## message ==> ', message)
  const Constructor = Vue.extend(Modal);
  const instance = new Constructor({
    propsData: { message }
  });
  
  instance.$mount(); // 手动挂载
  document.body.appendChild(instance.$el); // 将元素添加到DOM中
  
  // 定义关闭方法
  instance.close = () => {
    document.body.removeChild(instance.$el);
    instance.$destroy();
  };
  
  return instance;
}