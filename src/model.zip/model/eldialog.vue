<template>
  <div>
    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      custom-class="sjk-dialog"
      width="448px"
    >
      <div>
        <p class="custom-title">缺少内容如下:</p>
        <div class="custom-item" v-for="(item,index) in msgList" :key="index">
          <i
            class="el-icon-warning custom-icon"
            style="color: #eb702f; font-size: 18px"
          />
          <div class="custom-text">{{item}}</div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      dialogVisible: false,
      msgList: [
        '1.签约信息选项卡至少有一条交易条款数据'
      ]
    };
  },
  methods: {
    showModal(message) {
      console.log("## mesage ==> ", message);
      //   this.message = message;
      this.msgList = message
      this.dialogVisible = true;
    },
    closeModal() {
      this.dialogVisible = false;
    },
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then((_) => {
          done();
        })
        .catch((_) => {});
    },
  },
};
</script>

<style lang="scss">
.sjk-dialog {
  border-radius: 10px;
  .el-dialog__header {
    padding: 20px;
    border-radius: 10px;
    // background: linear-gradient(180deg, #FF6800 0%, #FFFFFF 22%);
    background: linear-gradient(180deg, #f6c6a1 0%, #ffffff 100%);
    .el-dialog__title {
      font-weight: bold;
    }
  }
  .el-dialog__body {
    padding-top: 0;
    padding-left: 44px;
    padding-right: 44px;
  }
  .custom-title {
    font-family: AlimamaShuHeiTi;
    font-size: 16px;
    color: #333333;
    font-weight: 700;
  }
  .custom-item {
    display: flex;
    // align-items: center;

  }

  .custom-icon {
    margin-right: 13px;
        margin-top: 2px;
  }

  .custom-text {
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #333333;
    font-weight: 400;
  }
}
</style>