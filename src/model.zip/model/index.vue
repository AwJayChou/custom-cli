<template>
  <div v-if="isVisible" class="modal">
    <!-- 弹窗内容 -->
    <div>{{ message }}</div>
    <button @click="closeModal">关闭</button>
  </div>
</template>
 
<script>
export default {
  data() {
    return {
      isVisible: false,
      message: '',
    };
  },
  methods: {
    showModal(message) {
      this.message = message;
      this.isVisible = true;
    },
    closeModal() {
      this.isVisible = false;
    },
  },
};
</script>
 
<style scoped>
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
}
</style>