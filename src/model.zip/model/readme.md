import Modal from './components/model';
import Eldialog from './components/model/eldialog';
import showModal from './components/model/api.js';
import showModal1 from './components/model/api1.js';
 
Vue.component('modal', Modal);
Vue.component('Eldialog', Eldialog);
// Vue.prototype.$dialog = showModal()
Vue.prototype.$dialog = showModal1()

this.$dialog.showModal(['showMessage'])